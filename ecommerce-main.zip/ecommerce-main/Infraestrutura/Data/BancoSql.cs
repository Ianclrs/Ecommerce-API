﻿using Dominio.Entidades;
namespace Infraestrutura.Data;
public static class BancoSql
{
    public static List<Produto> Produtos { get; set; } = new();
}
