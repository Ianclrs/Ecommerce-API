﻿namespace Infraestrutura
{
    public class Class1
    {

    }
}
